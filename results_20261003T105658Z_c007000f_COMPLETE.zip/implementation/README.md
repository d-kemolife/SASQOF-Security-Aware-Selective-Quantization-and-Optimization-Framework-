# ASR646 reproducibility source code

This package accompanies the revised manuscript and response sheet. It contains the implementation executed for the corrective analyses on the author's supplied CSV. Results are generated locally by the commands below; existing results are supplied separately in ASR646_Executed_Analysis_Package.zip.
It does not reconstruct the undocumented historical experiment or include ESP32
firmware. The author identified the CSV as real sensor measurements. Collection
site, calibrated units, acquisition and preprocessing history, label origin,
permissions and redistribution license remain unprovided. The raw CSV is excluded;
use the authorized source file, not generated substitute data.

## Source file identity and audit

Filename: SASQOF_Dataset.csv

SHA-256: 7025b53ed9842d9473b8d5f521639c09225d35feafd5be5254c982a170536ed3

There are 10,257 rows, 13 columns, 1,156 unique seven-input vectors, no empty
entries or duplicate timestamps, and seven all-zero environmental records
(identifiers 54–60) retained and flagged. Header whitespace is stripped. The
combined IRRIGATION PATTERN field exactly encodes the three labels and is excluded
from predictors. Every pump label agrees with its corresponding percentage input
being below 50; this observation does not establish how labels were generated.
Only five rain-positive records occur. All last 4,242 rows have pattern 101.

## Executed protocols

The results folders correspond to the manuscript, using the final executed runs:

- chronological_T1_final: 7,179/1,538/1,540 train/validation/test records.
- chronological_T12: 7,168/1,527/1,529 windows within those same row partitions.
- feature_group_T1_final: identical input vectors stay together, stratified by
  observed label pattern. Counts are 805/172/179 groups and 7,244/1,564/1,449 rows.

The input-group analysis is a class-diverse sensitivity, not chronological future
validation. It prevents identical input vectors crossing partitions, but does not
remove near duplicates or temporal correlation. Approximately 70/15/remainder
allocation is performed separately within each pattern, with at least one group
in every partition. Pattern 110 has only three groups, so a one-per-partition
allocation is required. Split shuffling uses seed 42. Model seeds are 42–46 on
fixed partitions. No selection of the best test split is performed.

The chronological validation and test sets contain only pattern 101; all models
including majority achieve 100% accuracy. Clay positive-class metrics and the
three-output macro F1 are undefined. Undefined ratios are JSON null. These outputs
must not be advertised as strong irrigation prediction or temporal learning.

## Models and measurements

Eight types are evaluated: majority, depth-five tree, ten-tree depth-ten forest,
per-output logistic classifiers, MLP widths 32/32, two-layer 32-unit FP32 LSTM,
dynamically quantized LSTM plus linear, and selectively quantized LSTM only.
Both quantized forms derive from the same selected trained FP32 checkpoint per
seed. Interfaces remain floating point; selective output weights/bias/sigmoid
remain FP32. There is no FP16 implementation or wholly integer graph. The internal
name LSTM_dynamic_INT8_all means both eligible LSTM and linear modules, not every
operator or tensor in integer arithmetic. Neither variant is an embedded engine.

Training uses ten epochs, Adam 0.01, batch size 64, training-only median imputation
(no missing entries actually trigger it), scaling of six continuous variables,
retained binary rain and labels, BCEWithLogitsLoss, minimum-validation-loss
checkpoint, and independent sigmoid threshold 0.5. Length twelve is a fixed
history sensitivity of about 22 minutes between first and last readings; it is
not an agronomically optimized forecast horizon. No node/site column is available,
so the chronological file is treated as one ordered multichannel table. Window
construction does not verify independent sensor identity. Nonrecurrent baselines
receive flattened versions of the same windows and are not parameter-matched.

Each model run has 50 warmups and 500 batch-one timings with one CPU thread.
Neural model-only time includes sigmoid, excludes preprocessing/packets, and uses
eval/inference mode. Timing output contains mean, sample SD, median and P95.
Tables summarize across five run means; individual timing variation is separate.
Model bytes are torch.save state_dict or joblib serialization, not peak RAM,
firmware flash, SRAM or a tensor arena. Different serializers limit cross-family
storage comparisons. CPU timings cannot establish ESP32 capability or water use.

Integrated plain inference includes current feature construction, preprocessing,
selective model and threshold. Authenticated inference additionally verifies a
packet, bounded timestamp and persistent sequence, including SQLite synchronous
FULL commit. Sender signing, network transmission and actuation are excluded.
For twelve-record windows, history is cached/trusted and only the current reading
is authenticated. History acquisition and window maintenance are not measured.
Packet lengths are 240–244 bytes plus a 32-byte tag across the chronological runs.
Separate timing blocks and host storage/scheduling limit generalizing overhead.

## Security evidence and limits

Twelve mechanical tests passed. Additionally, twelve cases each use 100 actual
CSV sensor payloads: valid, tampered, wrong key, replay, restart replay, expired,
future, revoked epoch, unknown device, malformed, failed authentication preserving
state, and out-of-order. All 1,200 expected behavior checks pass; see
results/audit_security/security_trials.json. These finite software cases do not
estimate real attack probability or prove field resilience or physical protection.

Provision `{device: (authorized_epoch, key_bytes)}` externally. There is no default
production key. Each software benchmark creates a random 32-byte ephemeral key.
Keys, bounded trustworthy clock, durable receiver state and sender counter
persistence are assumptions. Rotation/revocation needs authenticated provisioning.
SQLite is a host reference, not firmware or rollback protection. A legitimate
compromised sensor can authenticate false data. Application schema/range checks,
rate limits, safe actuation, hardware key protection, secure boot and wireless
integration remain deployment work. HMAC supplies integrity/authentication but
no confidentiality. Delayed first delivery can be accepted within the age window.

## Quick start

Extract this ZIP. Open a terminal in its root folder. Python 3.12.14 on Linux
x86_64 was used for the manuscript analyses. An x86/fbgemm CPU quantization
backend is required. Windows activation commands are supplied for convenience;
Windows execution has not been tested. Timing depends on the processor and host
workload and is not expected to match exactly on another machine.

Create a virtual environment:

```bash
python -m venv .venv
```

Linux/macOS shell: `source .venv/bin/activate`.
Windows PowerShell: `.venv\Scripts\Activate.ps1`.

Install the pinned CPU dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
```

Check dependencies, the exact source-file hash and twelve security unit tests:

```bash
python run_all.py --csv "path/to/original.csv" --check-only
```

Run all three protocols, the data/security audit and statistical summaries:

```bash
python run_all.py --csv "path/to/original.csv" --out results
```

The launcher uses the current Python interpreter and executes stages sequentially.
It rejects changed source bytes, mismatched package versions and an existing output
directory. After a failed run, preserve its logs and choose a new output directory
for a clean rerun. There are eight model types, five seeds and three protocols
(120 model evaluations). The statistical stage includes 2,000 bootstrap resamples.

Individual commands are also available:

```bash
python -m unittest discover -s code -p test_security.py -v
python code/audit_and_security.py "path/to/original.csv" --out results/audit_security
python code/evaluate.py "path/to/original.csv" --out results/chronological_T1_final
python code/evaluate.py "path/to/original.csv" --out results/chronological_T12 --sequence-length 12
python code/evaluate.py "path/to/original.csv" --out results/feature_group_T1_final --split feature_groups
python code/summarize.py "path/to/original.csv" --results results/feature_group_T1_final
```

Use empty output directories for evaluate.py; it rejects overwriting an existing
run. Run timing experiments sequentially to avoid competing workloads. Histories,
checkpoints, raw predictions, per-pump confusion counts and measures, split row
memberships, file hashes and timing samples are preserved. Original CSV row
indices in prediction/membership files are zero-based, while its id values start
at one. PyTorch torch.ao deprecation warnings are retained in execution logs;
the API shown in the source manuscript is intentionally used for inspection.

summarize.py reports exploratory conditional intervals: five paired-seed t
intervals describe training variation on one split, and 2,000 feature-group
bootstrap resamples for seed 42 condition on sampled groups. Temporal similarity
limits group exchangeability; neither interval establishes generalization to new
sites/seasons. A zero-error bootstrap interval is not a population error guarantee.

## Files

- `run_all.py`: source/version validation and sequential experiment launcher.
- `code/evaluate.py`: splitting, preprocessing, training, quantization, metrics,
  model storage and latency measurements.
- `code/audit_and_security.py`: CSV audit and 1,200 security behavior checks.
- `code/security.py`: HMAC packet authentication and persistent replay prevention.
- `code/test_security.py`: twelve mechanical security tests.
- `code/summarize.py`: conditional group-bootstrap and paired-seed statistics.
- `requirements.txt`, `package_versions.json`: exact executed package versions.
- `SHA256SUMS.json`: integrity hashes of this bundle's implementation files.

The raw CSV is excluded; use the original supplied file. The full executed
analysis package includes saved results and manuscript figures separately.
This code does not include ESP32 firmware, an FP16 deployment, or field trials.
