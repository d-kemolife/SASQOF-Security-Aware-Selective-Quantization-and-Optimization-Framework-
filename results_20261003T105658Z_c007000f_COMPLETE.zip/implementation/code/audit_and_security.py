"""Audit actual CSV and run packet rejection checks using its sensor payloads."""
from pathlib import Path
import argparse,hashlib,json,secrets,tempfile
import numpy as np,pandas as pd
from security import Receiver,encode_packet,sign
from evaluate import FEATURES,TARGETS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('csv',type=Path);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 d=pd.read_csv(a.csv);original=d.columns.tolist();d.columns=d.columns.str.strip();t=pd.to_datetime(d.datetime,utc=True)
 stats={c:dict(min=float(d[c].min()),median=float(d[c].median()),max=float(d[c].max()),mean=float(d[c].mean()),sd=float(d[c].std())) for c in FEATURES}
 rules={};agreement={}
 for x,y in zip(FEATURES[:3],TARGETS):
  positive=d.loc[d[y]==1,x];negative=d.loc[d[y]==0,x]
  rules[y]=dict(max_active_input=float(positive.max()),min_inactive_input=float(negative.min()),matches_less_than_50=int(((d[x]<50).astype(int)==d[y]).sum()),total=len(d))
  agreement[y]=int(((d[x]<50).astype(int)==d[y]).sum())
 # Observed agreement is an audit finding, not evidence about how labels were generated.
 report=dict(sha256=hashlib.sha256(a.csv.read_bytes()).hexdigest(),rows=len(d),original_columns=original,normalized_columns=d.columns.tolist(),timestamp_start=str(t.min()),timestamp_end=str(t.max()),gap_seconds=t.diff().dt.total_seconds().describe().to_dict(),unique_ids=int(d.id.nunique()),duplicate_timestamps=int(t.duplicated().sum()),missing=d.isna().sum().to_dict(),infinite=int(np.isinf(d[FEATURES+TARGETS].to_numpy()).sum()),unique_feature_vectors=len(d[FEATURES].drop_duplicates()),repeated_feature_rows=int(d[FEATURES].duplicated().sum()),conflicting_labels_for_same_inputs=int((d.groupby(FEATURES)[TARGETS].nunique().max(axis=1)>1).sum()),positives={c:int(d[c].sum()) for c in TARGETS},rain_positive=int(d.is_raining.sum()),zero_environment_rows=d.loc[(d.temperature==0)&(d.humidity==0)&(d.dew_point==0),'id'].astype(int).tolist(),threshold_agreement=rules,combined_pattern_matches=bool(np.all(d['IRRIGATION PATTERN']==100*d[TARGETS[0]]+10*d[TARGETS[1]]+d[TARGETS[2]])),statistics=stats,provenance='User identifies real sensor measurements; collection site, calibration, target-generation method and license not supplied',exclusions='None; zero-coded measurements retained and flagged; soil zeros not declared missing')
 (a.out/'audit.json').write_text(json.dumps(report,indent=2,allow_nan=False))
 d[FEATURES].describe().to_csv(a.out/'feature_statistics.csv');d[TARGETS].value_counts().rename('count').to_csv(a.out/'label_patterns.csv')
 security=[]
 for case in ['valid','tampered','wrong_key','replay','restart_replay','expired','future','revoked_epoch','unknown_device','malformed','failed_tag_state','out_of_order']:
  correct=0
  with tempfile.TemporaryDirectory() as td:
   key=secrets.token_bytes(32);keys={'node':('epoch',key)};db=str(Path(td)/'state.sqlite');r=Receiver(db,keys)
   try:
    for i in range(100):
     payload={c:float(d.iloc[i][c]) for c in FEATURES};seq=i*3+1
     msg=encode_packet('node','epoch',seq,payload,timestamp=1000);tag=sign(key,msg)
     if case in ['replay','restart_replay','out_of_order']:
      r.verify(msg,tag,now=1000)
      if case=='restart_replay':r.close();r=Receiver(db,keys)
      if case=='out_of_order':msg=encode_packet('node','epoch',seq-1 if seq>1 else 0,payload,timestamp=1000);tag=sign(key,msg)
     elif case=='tampered':msg=msg.replace(b'"temperature":',b'"temperature":9',1)
     elif case=='wrong_key':tag=sign(secrets.token_bytes(32),msg)
     elif case in ['expired','future','revoked_epoch','unknown_device']:
      msg=encode_packet('unknown' if case=='unknown_device' else 'node','old' if case=='revoked_epoch' else 'epoch',seq,payload,timestamp=900 if case=='expired' else 1100 if case=='future' else 1000);tag=sign(key,msg)
     elif case=='malformed':msg=b'{}';tag=sign(key,msg)
     elif case=='failed_tag_state':
      high=encode_packet('node','epoch',seq+100000,payload,timestamp=1000)
      try:r.verify(high,bytes(32),now=1000)
      except ValueError:pass
      else:raise RuntimeError('Failed authentication was accepted')
     try:
      returned=r.verify(msg,tag,now=1000)
      correct+=int(case in ['valid','failed_tag_state'] and returned==payload)
     except ValueError:
      correct+=int(case not in ['valid','failed_tag_state'])
   finally:r.close()
  security.append(dict(case=case,trials=100,expected_behavior_checks_passed=correct))
 if any(c['expected_behavior_checks_passed']!=100 for c in security):raise RuntimeError('Security checks failed')
 (a.out/'security_trials.json').write_text(json.dumps(security,indent=2))
 print(json.dumps({'audit_rows':len(d),'security_checks':sum(c['expected_behavior_checks_passed'] for c in security)}))
if __name__=='__main__':main()
