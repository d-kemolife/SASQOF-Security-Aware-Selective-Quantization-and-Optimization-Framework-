"""Corrective CPU evaluation run on the author supplied CSV in October 2026.
This is new reference code and does not reproduce the undocumented historical run.
Chronological evaluation is primary; unique-feature-group random splitting is a
class-diverse sensitivity analysis, not evidence of future or site generalization.
"""
import argparse
import copy
import hashlib
import io
import json
import platform
import random
import secrets
import sys
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
import torch
from torch import nn
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from security import Receiver, encode_packet, sign

FEATURES = ['sandy_percent', 'clay_percent', 'loamy_percent',
            'temperature', 'humidity', 'dew_point', 'is_raining']
TARGETS = ['sandy_pump_active', 'clay_pump_active', 'loamy_pump_active']


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, allow_nan=False), encoding='utf-8')


def ratio(a, b):
    return None if b == 0 else float(a/b)


def metrics(y, pred):
    rows = []
    for j, name in enumerate(TARGETS):
        t, v = y[:, j].astype(bool), pred[:, j].astype(bool)
        tp, tn = int((t & v).sum()), int((~t & ~v).sum())
        fp, fn = int((~t & v).sum()), int((t & ~v).sum())
        rows.append(dict(output=name, TP=tp, TN=tn, FP=fp, FN=fn,
                         positive_support=int(t.sum()), negative_support=int((~t).sum()),
                         precision=ratio(tp, tp+fp), recall=ratio(tp, tp+fn),
                         f1=ratio(2*tp, 2*tp+fp+fn), specificity=ratio(tn, tn+fp),
                         false_positive_rate=ratio(fp, fp+tn),
                         false_negative_rate=ratio(fn, fn+tp)))
    f1s = [row['f1'] for row in rows]
    return dict(subset_accuracy=float(np.all(y == pred, axis=1).mean()),
                label_accuracy=float((y == pred).mean()),
                macro_f1=None if None in f1s else float(np.mean(f1s)), per_pump=rows)


def timed(fn, warmup=50, repeats=500):
    for _ in range(warmup):
        fn()
    durations = []
    for _ in range(repeats):
        start = time.perf_counter_ns()
        fn()
        durations.append((time.perf_counter_ns()-start)/1e6)
    return dict(mean_ms=float(np.mean(durations)), sd_ms=float(np.std(durations, ddof=1)),
                median_ms=float(np.median(durations)), p95_ms=float(np.percentile(durations,95)),
                warmup=warmup, repetitions=repeats, batch_size=1), durations


class IrrigationLSTM(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm = nn.LSTM(7, 32, num_layers=2, batch_first=True)
        self.fc = nn.Linear(32, 3)
    def forward(self, x):
        hidden, _ = self.lstm(x)
        return self.fc(hidden[:, -1, :])  # logits; sigmoid applied for inference


class IrrigationMLP(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(width,32),nn.ReLU(),nn.Linear(32,32),
                                 nn.ReLU(),nn.Linear(32,3))
    def forward(self, x):
        return self.net(x.reshape(x.shape[0],-1))


def train(model, x, y, xv, yv, seed, out):
    loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(torch.from_numpy(x), torch.from_numpy(y)),
        batch_size=64, shuffle=True, generator=torch.Generator().manual_seed(seed))
    opt = torch.optim.Adam(model.parameters(),lr=0.01)
    lossfn = nn.BCEWithLogitsLoss()
    best, state, history = float('inf'), None, []
    for epoch in range(10):
        model.train()
        train_losses = []
        for xb,yb in loader:
            opt.zero_grad();loss=lossfn(model(xb),yb);loss.backward();opt.step()
            train_losses.append(float(loss.detach()))
        model.eval()
        with torch.inference_mode():
            vl = float(lossfn(model(torch.from_numpy(xv)),torch.from_numpy(yv)))
        history.append(dict(epoch=epoch+1, mean_batch_training_loss=float(np.mean(train_losses)),
                            validation_loss=vl))
        if vl < best:
            best=vl;state=copy.deepcopy(model.state_dict())
    model.load_state_dict(state);model.eval()
    torch.save(state,out)
    return model, history


def windows(frame, values, labels, length, groups=None):
    x,y,ids = [],[],[]
    keys = np.zeros(len(frame),dtype=int) if groups is None else groups
    for group in pd.unique(keys):
        positions=np.flatnonzero(keys == group)
        times=frame.iloc[positions]['datetime'].astype('int64').to_numpy()
        gaps=np.diff(times)
        positive=gaps[gaps > 0]
        limit=1.5*float(np.median(positive)) if len(positive) else float('inf')
        for end in range(length-1,len(positions)):
            ix=positions[end-length+1:end+1]
            dt=np.diff(frame.iloc[ix]['datetime'].astype('int64').to_numpy())
            if length > 1 and ((dt <= 0).any() or (dt > limit).any()):
                continue
            x.append(values[ix]);y.append(labels[ix[-1]]);ids.append(int(frame.iloc[ix[-1]]['_row']))
    if not x:
        raise ValueError('No valid windows; inspect timestamps, groups, and chosen sequence length')
    return np.asarray(x,dtype=np.float32),np.asarray(y,dtype=np.float32),ids


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('csv',type=Path);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--sequence-length',type=int,default=1)
    ap.add_argument('--group-column',default=None)
    ap.add_argument('--split',choices=['chronological','feature_groups'],default='chronological')
    args=ap.parse_args()
    if args.sequence_length < 1:
        raise ValueError('Sequence length must be positive')
    args.out.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(1)
    backend = 'x86' if 'x86' in torch.backends.quantized.supported_engines else 'fbgemm'
    if backend not in torch.backends.quantized.supported_engines:
        raise RuntimeError('This reference protocol requires a supported x86/fbgemm CPU backend')
    torch.backends.quantized.engine=backend
    df=pd.read_csv(args.csv)
    df.columns=df.columns.str.strip()
    required=FEATURES+TARGETS+['datetime']+([args.group_column] if args.group_column else [])
    missing=[c for c in required if c not in df]
    if missing:
        raise ValueError(f'Missing columns: {missing}')
    df['_row']=np.arange(len(df))
    df['datetime']=pd.to_datetime(df['datetime'],utc=True,errors='raise')
    if df['datetime'].isna().any():
        raise ValueError('Missing timestamp; audit and document exclusions first')
    for c in FEATURES+TARGETS:
        df[c]=pd.to_numeric(df[c],errors='raise')
    if np.isinf(df[FEATURES+TARGETS].to_numpy(dtype=float)).any():
        raise ValueError('Infinite measurement; audit and document treatment first')
    if df[TARGETS].isna().any().any() or not df[TARGETS].isin([0,1]).all().all():
        raise ValueError('Targets must be complete binary 0/1 labels; never standardize targets')
    if not df['is_raining'].dropna().isin([0,1]).all():
        raise ValueError('Confirm rain coding before evaluation')
    if args.group_column and df[args.group_column].isna().any():
        raise ValueError('Missing series identity')
    duplicate_key=['datetime']+([args.group_column] if args.group_column else [])
    if df.duplicated(duplicate_key).any():
        raise ValueError('Duplicate timestamps per series; resolve and document first')
    df=df.sort_values('datetime',kind='stable').reset_index(drop=True)
    n=len(df);a=int(n*.70);b=a+int(n*.15)
    if args.split == 'feature_groups':
        if args.sequence_length != 1:
            raise ValueError('Feature-group sensitivity is record-level only')
        ids=df.groupby(FEATURES,dropna=False,sort=False).ngroup().to_numpy()
        df['_feature_group']=ids
        unique=df.drop_duplicates('_feature_group')
        # Each feature vector must have one label pattern for this sensitivity.
        if df.groupby('_feature_group')[TARGETS].nunique().to_numpy().max() > 1:
            raise ValueError('Conflicting labels for identical inputs')
        pattern=unique[TARGETS].astype(str).agg(''.join,axis=1)
        rng=np.random.default_rng(42);tr=[];va=[];te=[]
        for value in sorted(pattern.unique()):
            group_ids=unique.loc[pattern==value,'_feature_group'].to_numpy().copy()
            if len(group_ids)<3:raise ValueError('Need at least three feature groups per pattern')
            rng.shuffle(group_ids)
            cut1=min(max(1,int(len(group_ids)*.70)),len(group_ids)-2)
            cut2=cut1+min(max(1,int(len(group_ids)*.15)),len(group_ids)-cut1-1)
            tr.extend(group_ids[:cut1]);va.extend(group_ids[cut1:cut2]);te.extend(group_ids[cut2:])
        frames={name:df[df['_feature_group'].isin(ix)].copy() for name,ix in
                [('train',tr),('validation',va),('test',te)]}
    else:
        frames={name:df.iloc[lo:hi].copy() for name,lo,hi in
                [('train',0,a),('validation',a,b),('test',b,n)]}
    if min(a,b-a,n-b) < args.sequence_length:
        raise ValueError('Insufficient rows for declared partitions/windows')
    if df.iloc[a-1]['datetime'] == df.iloc[a]['datetime'] or df.iloc[b-1]['datetime'] == df.iloc[b]['datetime']:
        raise ValueError('Split crosses equal timestamp block; choose grouped boundaries before rerun')
    train_raw=frames['train'][FEATURES].to_numpy(dtype=float)
    if np.isnan(train_raw).all(axis=0).any():
        raise ValueError('A training feature is entirely missing')
    imputer=SimpleImputer(strategy='median');imputer.fit(train_raw)
    scaler=StandardScaler().fit(imputer.transform(train_raw)[:,:6])
    joblib.dump(dict(imputer=imputer,scaler=scaler,features=FEATURES),args.out/'preprocessing.joblib')
    splits={};members={};counts={}
    for name,raw_frame in frames.items():
        f=raw_frame.reset_index(drop=True)
        v=imputer.transform(f[FEATURES].to_numpy(dtype=float));v[:,:6]=scaler.transform(v[:,:6])
        # Keep the rain indicator binary after filling from the training-only median.
        if not np.isin(v[:,-1],[0,1]).all():
            raise ValueError('Training median rain imputation is not binary; choose a documented policy')
        splits[name]=windows(f,v,f[TARGETS].to_numpy(dtype=float),args.sequence_length,
                             None if not args.group_column else f[args.group_column].to_numpy())
        counts[name]=dict(rows=len(f),windows=len(splits[name][0]),
                          start=str(f['datetime'].min()),end=str(f['datetime'].max()),
                          positives={c:int(f[c].sum()) for c in TARGETS})
        members[name]=dict(raw_rows=f['_row'].astype(int).tolist(),target_rows=splits[name][2])
    save_json(args.out/'split_membership.json',members)
    audit=dict(csv_sha256=hashlib.sha256(args.csv.read_bytes()).hexdigest(),rows=n,
               features=FEATURES,targets=TARGETS,metadata_excluded=['id','datetime','IRRIGATION PATTERN'],
               missing_values={c:int(df[c].isna().sum()) for c in FEATURES},
               partitions=counts,sequence_length=args.sequence_length,group_column=args.group_column,
               source_provenance='Author identifies real sensor measurements; site, devices, calibration and access license unprovided',
               split=args.split,
               target_generation='MUST be supplied by authors',
               protocol='Corrective CPU evaluation; not original result lineage')
    save_json(args.out/'dataset_audit.json',audit)
    save_json(args.out/'environment.json',dict(python=sys.version,torch=torch.__version__,
        numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__,
        platform=platform.platform(),processor=platform.processor(),cpu_model=next((l.split(':',1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),'unknown'),quantized_backend=backend,
        threads=torch.get_num_threads(),seeds=[42,43,44,45,46],epochs=10,batch_size=64,
        optimizer='Adam',learning_rate=.01,threshold=.5,checkpoint='minimum validation BCE'))
    x,y,_=splits['train'];xv,yv,_=splits['validation'];xt,yt,test_ids=splits['test']
    all_results=[]
    for seed in [42,43,44,45,46]:
        random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
        folder=args.out/f'seed_{seed}';folder.mkdir()
        fp,hist=train(IrrigationLSTM(),x,y,xv,yv,seed,folder/'lstm_fp32.pth')
        save_json(folder/'lstm_training.json',hist)
        # One trained source; quantization happens only after checkpoint selection.
        with warnings.catch_warnings():
            warnings.simplefilter('default')
            selective=torch.ao.quantization.quantize_dynamic(copy.deepcopy(fp),{nn.LSTM},dtype=torch.qint8)
            broad=torch.ao.quantization.quantize_dynamic(copy.deepcopy(fp),{nn.LSTM,nn.Linear},dtype=torch.qint8)
        torch.manual_seed(seed)
        mlp,hist=train(IrrigationMLP(x.shape[1]*7),x,y,xv,yv,seed,folder/'mlp_fp32.pth')
        save_json(folder/'mlp_training.json',hist)
        models={'LSTM_FP32':fp,'LSTM_dynamic_INT8_all':broad,
                'LSTM_selective_INT8_FP32':selective,'MLP_FP32':mlp}
        flat=x.reshape(len(x),-1);testflat=xt.reshape(len(xt),-1)
        tree=DecisionTreeClassifier(max_depth=5,random_state=seed).fit(flat,y.astype(int))
        forest=RandomForestClassifier(n_estimators=10,max_depth=10,random_state=seed,n_jobs=1).fit(flat,y.astype(int))
        models.update(DecisionTree=tree,RandomForest=forest)
        majority=DummyClassifier(strategy='most_frequent').fit(flat,y.astype(int))
        models['Majority']=majority
        logistic=[]
        for j in range(3):
            clf=DummyClassifier(strategy='most_frequent') if len(np.unique(y[:,j]))==1 else LogisticRegression(max_iter=2000,random_state=seed)
            logistic.append(clf.fit(flat,y[:,j].astype(int)))
        models['LogisticRegression']=logistic
        for name,model in models.items():
            if isinstance(model,nn.Module):
                model.eval()
                with torch.inference_mode():
                    probabilities=torch.sigmoid(model(torch.from_numpy(xt))).numpy()
                pred=(probabilities >= .5).astype(int)
                sample=torch.from_numpy(xt[:1])
                def run():
                    with torch.inference_mode():
                        return torch.sigmoid(model(sample))
                target=folder/f'{name}.pth';torch.save(model.state_dict(),target)
                serialization='torch.save state_dict'
            else:
                def predict(z):
                    return np.column_stack([m.predict(z) for m in model]) if isinstance(model,list) else model.predict(z)
                pred=predict(testflat).astype(int)
                def run():
                    return predict(testflat[:1])
                target=folder/f'{name}.joblib';joblib.dump(model,target)
                serialization='joblib; differs from neural state_dict serialization'
            timing,samples=timed(run)
            result=dict(seed=seed,model=name,**metrics(yt,pred),latency=timing,
                        serialized_bytes=target.stat().st_size,serialized_KiB=target.stat().st_size/1024,
                        serialization=serialization,peak_runtime_RAM='not measured',
                        ESP32_flash='not measured',ESP32_SRAM='not measured')
            save_json(folder/f'{name}_results.json',result)
            pd.DataFrame({'duration_ms':samples}).to_csv(folder/f'{name}_timing.csv',index=False)
            predfile=pd.DataFrame({'original_csv_row':test_ids})
            for j,col in enumerate(TARGETS):
                predfile[col+'_true']=yt[:,j].astype(int);predfile[col+'_pred']=pred[:,j]
            predfile.to_csv(folder/f'{name}_predictions.csv',index=False)
            all_results.append(result)
            print(args.split,args.sequence_length,seed,name,result['subset_accuracy'],flush=True)
        # CPU packet path timing, including signing only outside the measured call.
        # Local SQLite commit is deliberately included in receiver overhead.
        key=secrets.token_bytes(32);receiver=Receiver(str(folder/'receiver.sqlite'),{'benchmark-node':('one',key)})
        packet_fields={c:float(df.loc[df['_row']==test_ids[0],c].iloc[0]) for c in FEATURES}
        if any(not np.isfinite(v) for v in packet_fields.values()):
            packet_fields={c:float(imputer.statistics_[i]) if not np.isfinite(v) else v for i,(c,v) in enumerate(packet_fields.items())}
        pairs=[(msg,sign(key,msg)) for msg in [encode_packet('benchmark-node','one',i+1,packet_fields) for i in range(550)]]
        iterator=iter(pairs)
        def authenticated_run():
            message,tag=next(iterator);payload=receiver.verify(message,tag)
            current=np.array([[payload[c] for c in FEATURES]],dtype=float)
            current=imputer.transform(current);current[:,:6]=scaler.transform(current[:,:6])
            # For T>1, trusted history must be held separately. Do not substitute
            # unverified current data into each history step.
            window=xt[:1].copy();window[0,-1]=current[0]
            with torch.inference_mode():
                return (torch.sigmoid(selective(torch.from_numpy(window))) >= .5).numpy()
        try:
            sec,samples=timed(authenticated_run)
        finally:
            receiver.close()
        save_json(folder/'authenticated_inference.json',dict(latency=sec,
            first_packet_bytes=len(pairs[0][0]),packet_byte_range=[min(len(z[0]) for z in pairs),max(len(z[0]) for z in pairs)],tag_bytes=32,history_assumption='trusted cached historical window',
            scope='Verify HMAC, timestamp, persistent sequence; preprocess current record; model; threshold',
            note='CPU reference timing; sender signing excluded; not an ESP32 or network measurement'))
        pd.DataFrame({'duration_ms':samples}).to_csv(folder/'authenticated_inference_timing.csv',index=False)
        def plain_run():
            current=np.array([[packet_fields[c] for c in FEATURES]],dtype=float)
            current=imputer.transform(current);current[:,:6]=scaler.transform(current[:,:6])
            window=xt[:1].copy();window[0,-1]=current[0]
            with torch.inference_mode():
                return (torch.sigmoid(selective(torch.from_numpy(window))) >= .5).numpy()
        plain,plain_samples=timed(plain_run)
        save_json(folder/'plain_inference.json',dict(latency=plain,
            scope='Feature array construction, preprocessing, selective model, threshold; no packet verification',
            caveat='Separate timing blocks; host scheduling and SQLite storage affect differences'))
        pd.DataFrame({'duration_ms':plain_samples}).to_csv(folder/'plain_inference_timing.csv',index=False)
    summary=[]
    for name in sorted({z['model'] for z in all_results}):
        records=[z for z in all_results if z['model']==name]
        row={'model':name,'runs':len(records)}
        for metric in ['subset_accuracy','label_accuracy','macro_f1','serialized_bytes']:
            v=[z[metric] for z in records]
            row[metric+'_mean']=None if None in v else float(np.mean(v))
            row[metric+'_sd']=None if None in v else float(np.std(v,ddof=1))
        row['model_latency_mean_ms']=float(np.mean([z['latency']['mean_ms'] for z in records]))
        row['model_latency_between_run_sd_ms']=float(np.std([z['latency']['mean_ms'] for z in records],ddof=1))
        summary.append(row)
    save_json(args.out/'summary.json',summary)
    pd.DataFrame(summary).to_csv(args.out/'summary.csv',index=False)
    print(f'Wrote audited replacement results to {args.out}')


if __name__ == '__main__':
    main()
