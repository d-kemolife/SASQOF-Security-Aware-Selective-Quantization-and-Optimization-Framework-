"""Summarize exported predictions and perform exploratory group bootstrap."""
from pathlib import Path
import json, argparse
import numpy as np,pandas as pd
from scipy.stats import t
from evaluate import FEATURES,TARGETS

def main():
 ap=argparse.ArgumentParser();ap.add_argument('csv',type=Path);ap.add_argument('--results',type=Path,required=True);a=ap.parse_args()
 d=pd.read_csv(a.csv);d.columns=d.columns.str.strip();g=d.groupby(FEATURES,sort=False,dropna=False).ngroup().to_numpy()
 root=a.results;names=[r['model'] for r in json.loads((root/'summary.json').read_text())];rng=np.random.default_rng(20261002)
 tables={};pairs=[];draws=None
 for name in names:
  p=pd.read_csv(root/'seed_42'/f'{name}_predictions.csv');ids=p.original_csv_row.to_numpy();ys=p[[c+'_true' for c in TARGETS]].to_numpy();pred=p[[c+'_pred' for c in TARGETS]].to_numpy();good=np.all(ys==pred,axis=1);keys=g[ids];groups=np.unique(keys)
  counts=np.array([(keys==k).sum() for k in groups]);correct=np.array([good[keys==k].sum() for k in groups]);
  if draws is None:draws=rng.integers(0,len(groups),size=(2000,len(groups)))
  v=correct[draws].sum(axis=1)/counts[draws].sum(axis=1)
  tables[name]=dict(seed=42,subset_accuracy=float(good.mean()),conditional_feature_group_bootstrap_95CI=np.percentile(v,[2.5,97.5]).tolist(),groups=len(groups),replicates=2000)
 for other in ['LSTM_FP32','LSTM_dynamic_INT8_all','DecisionTree','MLP_FP32']:
  diff=[];identical=True
  for seed in range(42,47):
   p=pd.read_csv(root/f'seed_{seed}'/'LSTM_selective_INT8_FP32_predictions.csv');q=pd.read_csv(root/f'seed_{seed}'/f'{other}_predictions.csv')
   yp=p[[c+'_true' for c in TARGETS]].to_numpy();pp=p[[c+'_pred' for c in TARGETS]].to_numpy();qp=q[[c+'_pred' for c in TARGETS]].to_numpy();identical=identical and np.array_equal(pp,qp)
   diff.append(float(np.all(yp==pp,axis=1).mean()-np.all(yp==qp,axis=1).mean()))
  m=float(np.mean(diff));se=float(np.std(diff,ddof=1)/np.sqrt(5));pairs.append(dict(comparison='Selective minus '+other,mean_subset_accuracy_difference=m,seed_only_t95CI=[m-t.ppf(.975,4)*se,m+t.ppf(.975,4)*se],paired_differences=diff,predictions_identical_all_seeds=identical))
 obj=dict(interpretation='Exploratory conditional intervals. Five-seed intervals describe training variation on one fixed split. Feature-group bootstrap assumes sampled groups are exchangeable despite temporal similarity; neither establishes site/season generalization.',seed42_group_bootstrap=tables,paired_seed_comparisons=pairs)
 (root/'statistical_analysis.json').write_text(json.dumps(obj,indent=2))
 print(json.dumps(obj,indent=2))
if __name__=='__main__':main()
