"""Corrective CPU reference protocol, not recovered original firmware."""
import hashlib
import hmac
import json
import math
import sqlite3
import time


def encode_packet(device, epoch, seq, payload, timestamp=None):
    message = {"version": 1, "device": device, "epoch": epoch,
               "sequence": seq, "timestamp": time.time() if timestamp is None else timestamp,
               "payload": payload}
    return json.dumps(message, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def sign(key, message):
    if not isinstance(key, bytes) or len(key) < 32:
        raise ValueError("Provision a device-specific key with at least 32 random bytes")
    return hmac.new(key, message, hashlib.sha256).digest()


class Receiver:
    """One active authorized (epoch, key) per device; SQLite persists high-water marks.

    Deployment needs authenticated provisioning, protected keys, a trustworthy clock,
    sender counter persistence, controlled epoch rotation, and durable storage.
    SQLite provides a CPU reference only; it is not an ESP32 storage implementation.
    """
    def __init__(self, database, provisioned_keys, max_age=60.0, future_tolerance=10.0):
        self.keys = dict(provisioned_keys)
        for epoch, key in self.keys.values():
            if not isinstance(epoch, str) or not epoch or len(key) < 32:
                raise ValueError("Invalid provisioned epoch/key")
        self.max_age = float(max_age)
        self.future_tolerance = float(future_tolerance)
        self.db = sqlite3.connect(database, timeout=10, isolation_level=None)
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS counters "
                        "(device TEXT, epoch TEXT, seq INTEGER, PRIMARY KEY(device,epoch))")

    def close(self):
        self.db.close()

    def verify(self, message, tag, now=None):
        if not isinstance(message, bytes) or not isinstance(tag, bytes):
            raise ValueError("Packet and tag must be bytes")
        if len(message) > 8192 or len(tag) != 32:
            raise ValueError("Invalid packet length")
        try:
            packet = json.loads(message)
            if not isinstance(packet, dict) or set(packet) != {
                    "version", "device", "epoch", "sequence", "timestamp", "payload"}:
                raise ValueError("Invalid packet schema")
            device = packet["device"]
            if not isinstance(device, str) or not isinstance(packet["epoch"], str):
                raise ValueError("Invalid identity fields")
            epoch, key = self.keys[device]
        except (ValueError, KeyError, TypeError, UnicodeError) as exc:
            raise ValueError("Unknown device or malformed packet") from exc
        # The exact received bytes are authenticated, not a reserialized payload.
        if not hmac.compare_digest(sign(key, message), tag):
            raise ValueError("Authentication failure")
        if type(packet["version"]) is not int or packet["version"] != 1:
            raise ValueError("Unsupported version")
        if packet["epoch"] != epoch:
            raise ValueError("Unauthorized or revoked key epoch")
        seq = packet["sequence"]
        stamp = packet["timestamp"]
        if type(seq) is not int or not 1 <= seq < 2**63:
            raise ValueError("Invalid sequence")
        if type(stamp) not in (int, float) or not math.isfinite(stamp):
            raise ValueError("Invalid timestamp")
        now = time.time() if now is None else now
        if not -self.future_tolerance <= now-stamp <= self.max_age:
            raise ValueError("Expired or future packet")
        if not isinstance(packet["payload"], dict):
            raise ValueError("Invalid payload")
        # Lock, compare, and commit together to avoid duplicate concurrent acceptance.
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row = self.db.execute("SELECT seq FROM counters WHERE device=? AND epoch=?",
                                  (device, epoch)).fetchone()
            if row is not None and seq <= row[0]:
                raise ValueError("Duplicate or replayed sequence")
            self.db.execute("INSERT INTO counters VALUES (?,?,?) ON CONFLICT(device,epoch) "
                            "DO UPDATE SET seq=excluded.seq", (device, epoch, seq))
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK")
            raise
        return packet["payload"]
