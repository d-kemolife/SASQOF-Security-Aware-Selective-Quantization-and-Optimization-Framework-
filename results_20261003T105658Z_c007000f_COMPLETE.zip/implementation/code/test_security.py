"""Mechanical reference-protocol tests; no manuscript data or device experiments."""
import secrets
import tempfile
import unittest
from pathlib import Path
from security import Receiver, encode_packet, sign


class SecurityChecks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.tmp.name)/'state.sqlite')
        self.key = secrets.token_bytes(32)
        self.keys = {'node-a': ('epoch-1', self.key)}
        self.r = Receiver(self.path, self.keys)
    def tearDown(self):
        self.r.close()
        self.tmp.cleanup()
    def packet(self, seq=1, stamp=1000, device='node-a', epoch='epoch-1'):
        msg = encode_packet(device, epoch, seq, {'reading': 30}, timestamp=stamp)
        return msg, sign(self.key, msg)
    def test_valid(self):
        self.assertEqual(self.r.verify(*self.packet(), now=1000), {'reading': 30})
    def test_tampered(self):
        msg, tag = self.packet()
        with self.assertRaises(ValueError):
            self.r.verify(msg.replace(b'30', b'31'), tag, now=1000)
    def test_wrong_key(self):
        msg, tag = self.packet()
        with self.assertRaises(ValueError):
            self.r.verify(msg, sign(secrets.token_bytes(32), msg), now=1000)
    def test_replay(self):
        self.r.verify(*self.packet(), now=1000)
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(), now=1000)
    def test_persistent_restart(self):
        self.r.verify(*self.packet(), now=1000)
        self.r.close()
        self.r = Receiver(self.path, self.keys)
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(), now=1000)
    def test_failed_authentication_does_not_advance_counter(self):
        msg, tag = self.packet(seq=100)
        with self.assertRaises(ValueError):
            self.r.verify(msg, bytes(32), now=1000)
        self.r.verify(*self.packet(seq=1), now=1000)
    def test_out_of_order(self):
        self.r.verify(*self.packet(seq=2), now=1000)
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(seq=1), now=1000)
    def test_expired(self):
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(stamp=900), now=1000)
    def test_future(self):
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(stamp=1100), now=1000)
    def test_revoked_epoch(self):
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(epoch='old-epoch'), now=1000)
    def test_unknown_device(self):
        with self.assertRaises(ValueError):
            self.r.verify(*self.packet(device='unknown'), now=1000)
    def test_malformed(self):
        with self.assertRaises(ValueError):
            self.r.verify(b'{}', sign(self.key, b'{}'), now=1000)


if __name__ == '__main__':
    unittest.main(verbosity=2)
