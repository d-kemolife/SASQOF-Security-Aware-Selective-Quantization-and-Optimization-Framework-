"""Run the corrective ASR646 experiments sequentially on the supplied CSV."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import subprocess
import sys
import json

SOURCE_SHA256 = '7025b53ed9842d9473b8d5f521639c09225d35feafd5be5254c982a170536ed3'
ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', type=Path, required=True, help='Original, unmodified source CSV')
    parser.add_argument('--out', type=Path, default=Path('results'), help='New output directory; existing directories are rejected')
    parser.add_argument('--check-only', action='store_true', help='Check source identity, dependencies and security tests without training')
    args = parser.parse_args()
    csv = args.csv.resolve(strict=True)
    if hashlib.sha256(csv.read_bytes()).hexdigest() != SOURCE_SHA256:
        parser.error('CSV SHA-256 differs from the manuscript source. Use the original unmodified CSV.')
    expected = json.loads((ROOT / 'package_versions.json').read_text())
    for package, version in expected.items():
        try:
            installed = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            parser.error(f'{package} is missing; install requirements.txt')
        pass
    import torch
    if not {'x86', 'fbgemm'}.intersection(torch.backends.quantized.supported_engines):
        parser.error('An x86 or fbgemm CPU quantization backend is required.')
    print('Source hash and pinned dependency versions verified.', flush=True)
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(ROOT / 'code'), '-p', 'test_security.py', '-v'], check=True)
    if args.check_only:
        return
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    logs = out / 'logs'
    logs.mkdir()
    stages = [
        ('audit_security', 'audit_and_security.py', [str(csv), '--out', str(out / 'audit_security')]),
        ('chronological_T1_final', 'evaluate.py', [str(csv), '--out', str(out / 'chronological_T1_final')]),
        ('chronological_T12', 'evaluate.py', [str(csv), '--out', str(out / 'chronological_T12'), '--sequence-length', '12']),
        ('feature_group_T1_final', 'evaluate.py', [str(csv), '--out', str(out / 'feature_group_T1_final'), '--split', 'feature_groups']),
        ('statistical_analysis', 'summarize.py', [str(csv), '--results', str(out / 'feature_group_T1_final')]),
    ]
    for name, script, arguments in stages:
        print(f'Running {name}; progress log: {logs / (name + ".log")}', flush=True)
        with (logs / (name + '.log')).open('w', encoding='utf-8') as log:
            subprocess.run([sys.executable, str(ROOT / 'code' / script), *arguments], stdout=log, stderr=subprocess.STDOUT, check=True)
    print(f'Completed. Results: {out}', flush=True)


if __name__ == '__main__':
    main()
